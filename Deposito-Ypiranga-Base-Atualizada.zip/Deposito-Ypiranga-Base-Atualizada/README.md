# Projeto Base - Site da Empresa

Informações atuais:
- Nome atual: Depósito Ypiranga
- Cidade: Alto Paraná - PR
- Telefone: (44) 3447-3610

Planejado:
- A empresa mudará de nome.
- A empresa mudará de endereço.
- O projeto foi organizado para facilitar essas alterações.
